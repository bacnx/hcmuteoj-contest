#include <bits/stdc++.h>
using namespace std;

string s;
bool isReverse;

int main() {
	cin >> s;
	isReverse = false;

	int q; cin >> q;
	while (q--) {
		int t; cin >> t;
		if (t == 1) {
			isReverse ^= 1;
		}
		else {
			int f; cin >> f;
			char c; cin >> c;

			if(isReverse) {
				if (f == 2) f--;
				else f++;
			}

			if (f == 1) {
				s = c + s;
			}
			else {
				s = s + c;
			}
		}
	}
	cout << s;

	return 0;
}